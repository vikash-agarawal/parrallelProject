package com.cg.pp.bean;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Transactions 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="transactionid",length=10)
	private int transactionId;
	@Column(name="transactiontype",length=10)
	private String transactionType;
	@Column(name="amount",length=10)
	private double amount;
	public Transactions( String transactionType, double amount) {
		super();
		this.transactionType = transactionType;
		this.amount = amount;
	}
	public Transactions() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Transactions [transactionId=" + transactionId + ", transactionType=" + transactionType + ", amount="
				+ amount + "]";
	}
	
	
	
	
}
