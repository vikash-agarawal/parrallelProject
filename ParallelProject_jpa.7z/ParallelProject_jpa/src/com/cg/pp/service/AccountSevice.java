package com.cg.pp.service;

import com.cg.pp.bean.AccountHolder;
import com.cg.pp.dao.AccountDao;
import com.cg.pp.dao.IAccountDao;
import com.cg.pp.exception.AccountNotExistException;
import com.cg.pp.exception.NotEnoughBalanceException;

public class AccountSevice implements IAccountService{

	IAccountDao accountDao=null;
	public AccountSevice() {
		// TODO Auto-generated constructor stub
		accountDao = new AccountDao();
	}
	@Override
	public void createAccount(String firstName, String lastName, String mobileNo, String gender, int age,
			double amount) {
		// TODO Auto-generated method stub
		accountDao.createAccount(firstName, lastName,  mobileNo,  gender,  age, amount);
	}
	@Override
	public AccountHolder withdrawAmount(String mobileNo, double amount) throws NotEnoughBalanceException, AccountNotExistException {
		// TODO Auto-generated method stub
		return accountDao.withdrawAmount(mobileNo, amount);
	}
	@Override
	public AccountHolder depositAmount(String mobileNo, double amount) throws AccountNotExistException {
		// TODO Auto-generated method stub
		return accountDao.depositAmount(mobileNo, amount);
	}
	@Override
	public double showBalance(String mobileNo) throws AccountNotExistException {
		// TODO Auto-generated method stub
		return accountDao.showBalance(mobileNo);
	}
	@Override
	public void printTtansaction(String mobileNo) {
		// TODO Auto-generated method stub
		accountDao.printTtansaction(mobileNo);
	}
	@Override
	public String fundTransfer(String senderMobileNo, String receiverMobileNo, double amount) throws AccountNotExistException, NotEnoughBalanceException {
		// TODO Auto-generated method stub
		return accountDao.fundTransfer(senderMobileNo, receiverMobileNo, amount);
	}
	
	
}
