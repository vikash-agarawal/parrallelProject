package com.cg.pp.exception;

public class AccountNotExistException extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccountNotExistException(String error)
	{
		super(error);
	}

}
