package com.cg.mra.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.mra.beans.Account;
import com.cg.mra.beans.Wallet;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoimpl;
import com.cg.mra.exception.InsufficientBalanceExeption;
import com.cg.mra.exception.InvalidAccountException;

class AccountTest {
	AccountDao dao=new AccountDaoimpl();
	@Test
	void test() {
		 Account account=new Account(121,"vikash",new Wallet("1234",500));
		try {
			assertEquals(account, dao.createAccount(account));
		} catch (InvalidAccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	void test1() {
		try {
			assertEquals(700,dao.deposit("1234", 200));
		} catch (InvalidAccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	void test2() {
		try {
			assertEquals(300,dao.withdrow("1234", 400));
		} catch (InvalidAccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InsufficientBalanceExeption e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	void test3() {
		try {
			assertEquals(300,dao.showBalance("1234"));
		} catch (InvalidAccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
