package com.cg.mra.util;
import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;
import com.cg.mra.beans.Wallet;
public class AccountUtil {
static Map<String,Account> accountMap=new HashMap<>();
	
	static
{
		accountMap.put("1234", new Account(121,"vikash",new Wallet("1234",500)));
}

	public static HashMap<String,Account> getAccountMap() {
		return (HashMap<String, Account>) accountMap;
	}

	public static void setAccountMap(HashMap<String,Account> accountMap) {
		AccountUtil.accountMap = accountMap;
	}

}
