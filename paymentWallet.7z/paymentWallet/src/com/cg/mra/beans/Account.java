package com.cg.mra.beans;

import java.util.ArrayList;

public class Account {
	private long accountNumber;
	private String customerName;
	private Wallet wallet;
	private ArrayList<Transaction> transactionList=new ArrayList<Transaction>();
	public Account(long accountNumber, String customerName, Wallet wallet) {
		super();
		this.accountNumber = accountNumber;
		this.customerName = customerName;
		this.wallet = wallet;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Wallet getWallet() {
		return wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	public ArrayList<Transaction> getTransactionList() {
		return transactionList;
	}
	public void setTransactionList(ArrayList<Transaction> transactionList) {
		this.transactionList = transactionList;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (accountNumber ^ (accountNumber >>> 32));
		result = prime * result + ((customerName == null) ? 0 : customerName.hashCode());
		result = prime * result + ((transactionList == null) ? 0 : transactionList.hashCode());
		result = prime * result + ((wallet == null) ? 0 : wallet.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (accountNumber != other.accountNumber)
			return false;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (transactionList == null) {
			if (other.transactionList != null)
				return false;
		} else if (!transactionList.equals(other.transactionList))
			return false;
		if (wallet == null) {
			if (other.wallet != null)
				return false;
		} else if (!wallet.equals(other.wallet))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "accountNumber=" + accountNumber + " \ncustomerName=" + customerName + " \nmobile Numbert="
				+ "" + wallet.getMobileNO()+"\nAccount Balance="+wallet.getAccountBalance();
	}
	public Account() {
		
	}
	
}
	
