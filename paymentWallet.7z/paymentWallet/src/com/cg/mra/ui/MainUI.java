/**
 * 
 */
package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.beans.Wallet;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceimpl;

public class MainUI {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccountService service=new AccountServiceimpl();
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("\n Enter1 for creating Account..\n Enter 2 for Deposit.. \n Enter "
					+ "3 for Withdrowal..\n Enter 4 for Fund Transfer..\n Enter 5 for "
					+ "Show Blance..\n Enter 6 for Print Transactions..\n Enter 7 for exit..");
			int choice=sc.nextInt();
			try {
			switch(choice)
			{
			case 1:System.out.println("\nEnter your name");
			       String name=sc.next();
			       name+=sc.nextLine();
			       System.out.println("\nEnter your mobileNo");
			       String mobileNo=sc.next();
			       while(true)
			       {
			    	   if(service.isValidMobileNo(mobileNo))
			    	   {
			    		   break;
			    	   }
			    	   else
			    	   {
			    		   System.out.println("Mobile number is not valid"
			    		   		+ "\n It should of 10 diits"
			    		   		+ "\n please enter another mobile number");
			    		    mobileNo=sc.next();
			    	   }
			       }
			       System.out.println("\nEnter your Account number");
			       long accno=sc.nextLong();
			       System.out.println("\nEnter the Amount");
			       double amount=sc.nextDouble();
			       Account account=new Account(accno,name,new Wallet(mobileNo,amount));
			       System.out.println(service.createAccount(account));
			       break;
			case 2:System.out.println("\nEnter the wallet mobile number");
			       String mobileno=sc.next();
			       while(true)
			       {
			    	   if(service.isValidMobileNo(mobileno))
			    	   {
			    		   break;
			    	   }
			    	   else
			    	   {
			    		   System.out.println("Mobile number is not valid"
			    		   		+ "\n It should of 10 diits"
			    		   		+ "\n please enter another mobile number");
			    		    mobileno=sc.next();
			    	   }
			       }
			       System.out.println("\nEnter the depositing amount");
			       double rechargeamount=sc.nextDouble();
			       System.out.println("\nYour Current "
			       		+ "Balance is::"+service.deposit(mobileno, rechargeamount));
			       break;
			case 3:System.out.println("\nEnter the wallet mobile number");
		           String mobileno1=sc.next();
		           while(true)
			       {
			    	   if(service.isValidMobileNo(mobileno1))
			    	   {
			    		   break;
			    	   }
			    	   else
			    	   {
			    		   System.out.println("Mobile number is not valid"
			    		   		+ "\n It should of 10 diits"
			    		   		+ "\n please enter another mobile number");
			    		    mobileno1=sc.next();
			    	   }
			       }
		           System.out.println("\nEnter the withdrowing amount");
		           double withdrowamount=sc.nextDouble();
		           System.out.println("\nYour Current "
				       		+ "Balance is::"+service.withdrow(mobileno1, withdrowamount));
		           break;
			case 4:System.out.println("\nEnter giver mobile number");
			       String giverMobileNo=sc.next();
			       while(true)
			       {
			    	   if(service.isValidMobileNo(giverMobileNo))
			    	   {
			    		   break;
			    	   }
			    	   else
			    	   {
			    		   System.out.println("Mobile number is not valid"
			    		   		+ "\n It should of 10 diits"
			    		   		+ "\n please enter another mobile number");
			    		   giverMobileNo=sc.next();
			    	   }
			       }
			       System.out.println("\nEnter Gainers mobile number");
			       String gainerMobileNo=sc.next();
			       while(true)
			       {
			    	   if(service.isValidMobileNo(gainerMobileNo))
			    	   {
			    		   break;
			    	   }
			    	   else
			    	   {
			    		   System.out.println("Mobile number is not valid"
			    		   		+ "\n It should of 10 diits"
			    		   		+ "\n please enter another mobile number");
			    		   gainerMobileNo=sc.next();
			    	   }
			       }
			       System.out.println("\nEnter amount");
			       double Amount=sc.nextDouble();
			       System.out.println("\n"+service.fundTransfer(giverMobileNo, Amount, gainerMobileNo));
			       break;
			case 5:System.out.println("\nEnter your mobile number");
			       String mobile=sc.next();
			       while(true)
			       {
			    	   if(service.isValidMobileNo(mobile))
			    	   {
			    		   break;
			    	   }
			    	   else
			    	   {
			    		   System.out.println("Mobile number is not valid"
			    		   		+ "\n It should of 10 diits"
			    		   		+ "\n please enter another mobile number");
			    		   mobile=sc.next();
			    	   }
			       }
			       System.out.println("\nYour Current "
				       		+ "Balance is::"+service.showBalance(mobile));
			       break;
			case 6:System.out.println("\nEnter your mobile number");
			       String mobileno2=sc.next();
			       while(true)
			       {
			    	   if(service.isValidMobileNo(mobileno2))
			    	   {
			    		   break;
			    	   }
			    	   else
			    	   {
			    		   System.out.println("Mobile number is not valid"
			    		   		+ "\n It should of 10 diits"
			    		   		+ "\n please enter another mobile number");
			    		   mobileno2=sc.next();
			    	   }
			       }
			       System.out.println(""+service.printTransaction(mobileno2));
			       break;
			case 7:System.exit(0);
			}
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
	}

}
