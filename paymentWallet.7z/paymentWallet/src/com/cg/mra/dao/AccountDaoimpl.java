package com.cg.mra.dao;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.mra.beans.Account;
import com.cg.mra.beans.Transaction;
import com.cg.mra.exception.InsufficientBalanceExeption;
import com.cg.mra.exception.InvalidAccountException;
import com.cg.mra.util.AccountUtil;

public class AccountDaoimpl implements AccountDao {
	HashMap<String,Account> accountEntry;
	public AccountDaoimpl() {
		accountEntry=AccountUtil.getAccountMap();
	}
	@Override
	public Account createAccount(Account account) throws InvalidAccountException {
		if(accountEntry.containsKey(account.getWallet().getMobileNO()))
				{
			throw new InvalidAccountException("Account already present with this number"
					+ "\n Please enter another mobile number");
	}
		else
		{
			accountEntry.put(account.getWallet().getMobileNO(), account);
			AccountUtil.setAccountMap(accountEntry);
			return account;
		}
	}
	@Override
	public double showBalance(String mobileNo) throws InvalidAccountException {
		if(accountEntry.containsKey(mobileNo))
		{
		double amount=accountEntry.get(mobileNo).getWallet().getAccountBalance();
		return amount;
	}
		else
		{
			throw new InvalidAccountException("Account does not exists with this number"
					+ "\n Please enter existing mobile number");
		}
	}
	@Override
	public double deposit(String mobileNo, double rechargeamount) throws InvalidAccountException {
		if(accountEntry.containsKey(mobileNo))
		{
		Account account=accountEntry.get(mobileNo);
		account.getWallet().setAccountBalance(account.getWallet().getAccountBalance()+rechargeamount);
		LocalDateTime dt=LocalDateTime.now();
		account.getTransactionList().add(new Transaction(dt,"Deposit",rechargeamount));
		return account.getWallet().getAccountBalance();
	}
		else
		{
			throw new InvalidAccountException("Account does not exists with this number"
					+ "\n Please enter existing mobile number");
		}
	}
	@Override
	public double withdrow(String mobileNo, double withdrawamount) throws InvalidAccountException, InsufficientBalanceExeption {
		if(accountEntry.containsKey(mobileNo))
		{
		Account account=accountEntry.get(mobileNo);
		if(account.getWallet().getAccountBalance()<=withdrawamount)
		{
			throw new InsufficientBalanceExeption("Your balance is not sufficient for this transacton");
		}
		else
		{
		account.getWallet().setAccountBalance(account.getWallet().getAccountBalance()-withdrawamount);
		LocalDateTime dt=LocalDateTime.now();
		account.getTransactionList().add(new Transaction(dt,"Withdrow",withdrawamount));
		return account.getWallet().getAccountBalance();
		}
	}
		else
		{
			throw new InvalidAccountException("Account does not exists with this number"
					+ "\n Please enter existing mobile number");
		}
	}
	@Override
	public String fundTransfer(String giverMobileNo, double amount, String gainerMobileNo) throws InvalidAccountException {
		if(accountEntry.containsKey(gainerMobileNo)&& accountEntry.containsKey(giverMobileNo))
		{
		Account account=accountEntry.get(giverMobileNo);
		account.getWallet().setAccountBalance(account.getWallet().getAccountBalance()-amount);
		Account account1=accountEntry.get(gainerMobileNo);
		account1.getWallet().setAccountBalance(account1.getWallet().getAccountBalance()+amount);
		LocalDateTime dt=LocalDateTime.now();
		account1.getTransactionList().add(new Transaction(dt,"Deposit",amount));
		account.getTransactionList().add(new Transaction(dt,"WithDrow",amount));
		return "your transfer got successfully";
	}
		else
		{
			throw new InvalidAccountException("Account does not exists with this number"
					+ "\n Please enter existing mobile number");
		}
	}
	@Override
	public ArrayList<Transaction> printTransaction(String mobileNo) throws InvalidAccountException {
		if(accountEntry.containsKey(mobileNo))
		{
		Account account=accountEntry.get(mobileNo);
		return account.getTransactionList();
	}
		else
		{
			throw new InvalidAccountException("Account does not exists with this number"
					+ "\n Please enter existing mobile number");
		}
	}
	
	}
