package com.cg.mra.dao;
import java.util.ArrayList;

import com.cg.mra.beans.*;
import com.cg.mra.exception.InsufficientBalanceExeption;
import com.cg.mra.exception.InvalidAccountException;
public interface AccountDao {
	public Account createAccount(Account account) throws InvalidAccountException;
	public double showBalance(String mobileNo) throws InvalidAccountException;
	public double deposit(String mobileNo, double rechargeamount) throws InvalidAccountException;
	public double withdrow(String mobileNo, double withdrowamount) throws InvalidAccountException, InsufficientBalanceExeption;
	public String fundTransfer(String giverMobileNo, double Amount, String gainerMobileNo) throws InvalidAccountException;
	public ArrayList<Transaction> printTransaction(String mobileNo) throws InvalidAccountException;
}
