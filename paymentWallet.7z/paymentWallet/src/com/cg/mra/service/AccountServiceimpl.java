package com.cg.mra.service;
import com.cg.mra.dao.*;
import com.cg.mra.exception.InsufficientBalanceExeption;
import com.cg.mra.exception.InvalidAccountException;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.beans.Transaction;

public class AccountServiceimpl implements AccountService {
	AccountDao dao=new AccountDaoimpl();

	@Override
	public Account createAccount(Account account) throws InvalidAccountException {
		
		return dao.createAccount(account);
	}

	@Override
	public double showBalance(String mobileNo) throws InvalidAccountException {
		
		return dao.showBalance(mobileNo);
	}

	@Override
	public double deposit(String mobileNo, double rechargeamount) throws InvalidAccountException {
		
		return dao.deposit(mobileNo, rechargeamount);
	}

	@Override
	public double withdrow(String mobileNo, double withdrowamount) throws InvalidAccountException, InsufficientBalanceExeption {
		
		return dao.withdrow(mobileNo, withdrowamount);
	}

	@Override
	public String fundTransfer(String giverMobileNo, double Amount, String gainerMobileNo) throws InvalidAccountException {
		
		return dao.fundTransfer(giverMobileNo, Amount, gainerMobileNo);
	}

	@Override
	public ArrayList<Transaction> printTransaction(String mobileNo) throws InvalidAccountException {
		return dao.printTransaction(mobileNo);
	}

	@Override
	public boolean isValidMobileNo(String mobileNo) {
		if(Pattern.matches("[0-9]{10}", mobileNo))
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
}
