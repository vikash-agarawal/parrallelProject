package com.cg.mra.exception;

public class InsufficientBalanceExeption extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InsufficientBalanceExeption(String str) {
		super(str);
	}

}
